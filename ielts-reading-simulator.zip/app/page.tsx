'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { Bookmark, Check, ChevronLeft, ChevronRight, Highlighter, Pause, Play, RotateCcw } from 'lucide-react'

const samplePassage = `Marie Curie is probably the most famous woman scientist who has ever lived. Born Maria Sklodowska in Poland in 1867, she is famous for her work on radioactivity, and was twice a winner of the Nobel Prize. With her husband, Pierre Curie, and Henri Becquerel, she was awarded the 1903 Nobel Prize for Physics, and was then sole winner of the 1911 Nobel Prize for Chemistry. She was the first woman to win a Nobel Prize.\n\nFrom childhood, Marie was remarkable for her prodigious memory, and at the age of 16 won a gold medal on completion of her secondary education. Because her father lost his savings through bad investment, she then had to take work as a teacher. From her earnings she was able to finance her sister Bronia's medical studies in Paris, on the understanding that Bronia would, in turn, later help her to get an education.\n\nIn 1891 this promise was fulfilled and Marie went to Paris and began to study at the Sorbonne (the University of Paris). She often worked far into the night and lived on little more than bread and butter and tea.`
const sampleQuestions = `Questions 1–6\nChoose TRUE if the statement agrees with the information given in the text, choose FALSE if the statement contradicts the information, or choose NOT GIVEN if there is no information on this.\n\n1. Marie Curie's husband was a joint winner of both Marie's Nobel Prizes.\nTRUE / FALSE / NOT GIVEN\n\n2. Marie became interested in science when she was a child.\nTRUE / FALSE / NOT GIVEN\n\n3. Marie had to work as a teacher because her father was poor.\nTRUE / FALSE / NOT GIVEN`

type Part = { passage: string; questions: string }
type Mode = 'setup' | 'test' | 'review'
const emptyParts: Part[] = [{ passage: '', questions: '' }, { passage: '', questions: '' }, { passage: '', questions: '' }]

export default function Page() {
  const [mode, setMode] = useState<Mode>('setup')
  const [parts, setParts] = useState<Part[]>(emptyParts)
  const [currentPart, setCurrentPart] = useState(0)
  const [paneRatio, setPaneRatio] = useState(50)
  const [answers, setAnswers] = useState<Record<string, string>>({})
  const [selectedQuestion, setSelectedQuestion] = useState(1)
  const [minutes, setMinutes] = useState(60)
  const [seconds, setSeconds] = useState(3600)
  const [paused, setPaused] = useState(false)
  const [highlightCount, setHighlightCount] = useState(0)
  const [questionHighlightCount, setQuestionHighlightCount] = useState(0)
  const [selectionMenu, setSelectionMenu] = useState<{ left: number; top: number } | null>(null)
  const passageRef = useRef<HTMLDivElement>(null)
  const questionsRef = useRef<HTMLElement>(null)
  const pendingSelection = useRef<Range | null>(null)
  const active = parts[currentPart]
  const availableParts = parts.map((part, index) => part.passage.trim() && part.questions.trim() ? index : -1).filter((index) => index >= 0)
  const questionLines = useMemo(() => active.questions.split('\n').filter((line) => /^\s*\d+[.)]/.test(line)), [active.questions])
  const paragraphs = useMemo(() => active.passage.split(/\n\s*\n/).filter(Boolean), [active.passage])
  const answeredCount = Object.keys(answers).filter((key) => key.startsWith(`${currentPart}-`) && answers[key]).length
  const timeLabel = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`

  useEffect(() => {
    if (mode !== 'test' || paused || seconds <= 0) return
    const timer = window.setInterval(() => setSeconds((value) => Math.max(0, value - 1)), 1000)
    return () => window.clearInterval(timer)
  }, [mode, paused, seconds])

  useEffect(() => {
    if (mode === 'test' && seconds === 0) setMode('review')
  }, [mode, seconds])

  const updatePart = (index: number, field: keyof Part, value: string) => setParts((items) => items.map((part, i) => i === index ? { ...part, [field]: value } : part))
  const startTest = () => { const first = availableParts[0]; if (first === undefined) return; setCurrentPart(first); setSelectedQuestion(1); setSeconds(minutes * 60); setPaused(false); setMode('test') }
  const backToSetup = () => { setMode('setup'); setSelectionMenu(null); setPaused(false) }
  const switchPart = (index: number) => { if (!availableParts.includes(index)) return; setCurrentPart(index); setSelectedQuestion(1); setHighlightCount(0); setQuestionHighlightCount(0); setSelectionMenu(null) }
  const handleSplitterPointerDown = (event: React.PointerEvent<HTMLButtonElement>) => {
    event.currentTarget.setPointerCapture(event.pointerId)
    const move = (moveEvent: PointerEvent) => {
      const workspace = document.querySelector('.reading-workspace') as HTMLElement | null
      if (!workspace) return
      const bounds = workspace.getBoundingClientRect()
      const nextRatio = ((moveEvent.clientX - bounds.left) / bounds.width) * 100
      setPaneRatio(Math.min(72, Math.max(28, nextRatio)))
    }
    const stop = () => {
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', stop)
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', stop, { once: true })
  }
  const captureSelection = () => {
    const selection = window.getSelection()
    const anchor = selection?.anchorNode
    const insidePassage = Boolean(anchor && passageRef.current?.contains(anchor))
    const insideQuestions = Boolean(anchor && questionsRef.current?.contains(anchor))
    if (!selection?.rangeCount || !selection.toString().trim() || (!insidePassage && !insideQuestions)) { setSelectionMenu(null); return }
    const range = selection.getRangeAt(0).cloneRange()
    pendingSelection.current = range
    const rect = range.getBoundingClientRect()
    setSelectionMenu({ left: Math.max(8, rect.left + rect.width / 2), top: Math.max(8, rect.top - 42) })
  }
  const highlightSelection = () => {
    const range = pendingSelection.current
    const inPassage = Boolean(range && passageRef.current?.contains(range.commonAncestorContainer))
    const inQuestions = Boolean(range && questionsRef.current?.contains(range.commonAncestorContainer))
    if (!range || (!inPassage && !inQuestions)) return
    const mark = document.createElement('mark'); mark.className = 'saved-highlight'
    try { range.surroundContents(mark) } catch { document.execCommand('hiliteColor', false, '#f7e67c') }
    if (inPassage) setHighlightCount((count) => count + 1)
    if (inQuestions) setQuestionHighlightCount((count) => count + 1)
    pendingSelection.current = null; setSelectionMenu(null); window.getSelection()?.removeAllRanges()
  }
  const clearPassageHighlights = () => {
    passageRef.current?.querySelectorAll('mark.saved-highlight').forEach((mark) => mark.replaceWith(...Array.from(mark.childNodes)))
    setHighlightCount(0)
  }
  const submitTest = () => { setPaused(false); setSelectionMenu(null); pendingSelection.current = null; setMode('review') }
  const selectAnswer = (number: number, value: string) => { if (mode === 'review') return; setAnswers((items) => ({ ...items, [`${currentPart}-${number}`]: value })) }
  const moveQuestion = (direction: number) => setSelectedQuestion((number) => Math.min(Math.max(1, number + direction), Math.max(1, questionLines.length)))

  if (mode === 'setup') return <Setup parts={parts} minutes={minutes} setMinutes={setMinutes} updatePart={updatePart} onStart={startTest} />
  return <main className="ielts-app">
    <header className="test-header"><div className="brand">IELTS</div><div className="test-title">Reading Test <span>{mode === 'review' ? 'Review mode — answers locked' : `${timeLabel} remaining`}</span></div></header>
    <section className="instruction-bar"><div><strong>Part {currentPart + 1}</strong><span>{mode === 'review' ? 'Review your answers. You cannot change them.' : `Read the text and answer questions ${currentPart * 13 + 1}–${currentPart * 13 + Math.max(1, questionLines.length)}.`}</span></div>{mode === 'test' && <button onClick={() => setPaused((value) => !value)} aria-label={paused ? 'Resume timer' : 'Pause timer'}>{paused ? <Play size={18} /> : <Pause size={18} />}</button>}</section>
    {mode === 'review' && <div className="review-banner"><Check size={18} /> Bài làm đã kết thúc. Đáp án hiện đang ở chế độ chỉ xem.</div>}
    <section className="reading-workspace" style={{ '--passage-ratio': `${paneRatio}%`, '--questions-ratio': `${100 - paneRatio}%` } as React.CSSProperties}><article className="passage-pane"><div className="pane-heading"><div><p className="eyebrow">Reading Passage</p><h1>Passage {currentPart + 1}</h1></div><div className="highlight-actions"><span>{highlightCount} passage · {questionHighlightCount} questions</span>{mode === 'test' && <button className="tool-button" onClick={clearPassageHighlights} disabled={!highlightCount}><RotateCcw size={14} /> Xóa highlight passage</button>}</div></div><div ref={passageRef} className="passage-content" onMouseUp={mode === 'test' ? captureSelection : undefined}>{paragraphs.map((paragraph, index) => <p key={index}>{paragraph}</p>)}</div>{selectionMenu && mode === 'test' && <button className="selection-highlight-button" style={{ left: selectionMenu.left, top: selectionMenu.top }} onMouseDown={(event) => event.preventDefault()} onClick={highlightSelection}><Highlighter size={14} /> Highlight</button>}</article><div className="divider"><button className="splitter-handle" type="button" aria-label="Resize passage and questions" title="Kéo để thay đổi kích thước hai cột" onPointerDown={handleSplitterPointerDown}>↔</button></div><article ref={questionsRef} className="questions-pane" onMouseUp={mode === 'test' ? captureSelection : undefined}><div className="pane-heading"><div><p className="eyebrow">Questions {currentPart * 13 + 1}–{currentPart * 13 + Math.max(1, questionLines.length)}</p><h2>{mode === 'review' ? 'Review answers' : 'Answer the questions'}</h2></div><Bookmark size={21} /></div><div className="question-instructions">{active.questions.split('\n').filter((line) => line.trim() && !/^\s*\d+[.)]/.test(line)).slice(0, 2).map((line, index) => <p key={index}>{line}</p>)}</div><div className="question-list">{questionLines.map((line) => { const number = Number(line.match(/^\s*(\d+)/)?.[1]); const prompt = line.replace(/^\s*\d+[.)]?\s*/, ''); const value = answers[`${currentPart}-${number}`] ?? ''; return <div key={number} className={`question-card ${selectedQuestion === number ? 'active' : ''}`} onClick={() => setSelectedQuestion(number)}><div className="question-top"><span className="question-number">{number}</span><p>{prompt}</p></div>{/TRUE|FALSE|NOT GIVEN/i.test(active.questions) && <div className="answer-options">{['TRUE', 'FALSE', 'NOT GIVEN'].map((option) => <label key={option}><input type="radio" name={`question-${currentPart}-${number}`} checked={value === option} disabled={mode === 'review'} onChange={() => selectAnswer(number, option)} /> {option}</label>)}</div>}<input className="answer-input" aria-label={`Answer ${number}`} placeholder="Type your answer here" value={value} disabled={mode === 'review'} onChange={(event) => selectAnswer(number, event.target.value)} /></div> })}</div></article></section>
    <footer className="test-footer"><div className="part-nav"><strong>Part {currentPart + 1}</strong>{questionLines.map((line) => { const number = Number(line.match(/^\s*(\d+)/)?.[1]); return <button key={number} className={selectedQuestion === number ? 'current' : answers[`${currentPart}-${number}`] ? 'answered' : ''} onClick={() => setSelectedQuestion(number)}>{number}</button> })}</div><div className="footer-meta">{answeredCount} of {questionLines.length} answered</div><div className="footer-controls"><button onClick={() => moveQuestion(-1)} aria-label="Previous question"><ChevronLeft /></button><button className="next" onClick={() => { if (selectedQuestion < questionLines.length) moveQuestion(1); else { const next = availableParts[availableParts.indexOf(currentPart) + 1]; if (next !== undefined) switchPart(next) } }} aria-label="Next question"><ChevronRight /></button></div><div className="part-switcher">{availableParts.map((part) => <button key={part} className={part === currentPart ? 'selected' : ''} onClick={() => switchPart(part)}>Part {part + 1}</button>)}</div><button className="back-setup-button" onClick={backToSetup}>Back to setup</button>{mode === 'test' && <button className="submit-button" onClick={submitTest} aria-label="Submit test" title="Nộp bài"><Check size={26} /></button>}</footer>
  </main>
}

function Setup({ parts, minutes, setMinutes, updatePart, onStart }: { parts: Part[]; minutes: number; setMinutes: (value: number) => void; updatePart: (index: number, field: keyof Part, value: string) => void; onStart: () => void }) {
  const useSample = () => { updatePart(0, 'passage', samplePassage); updatePart(0, 'questions', sampleQuestions) }
  const ready = parts.some((part) => part.passage.trim() && part.questions.trim())
  return <main className="setup-page"><div className="setup-shell"><div className="setup-brand"><div className="brand">IELTS</div><span>Reading workspace</span></div><div className="setup-intro"><p className="eyebrow">Personal practice tool</p><h1>Create your reading test</h1><p>Nhập passage và câu hỏi cho từng part. Bạn chỉ cần nhập ít nhất một part để bắt đầu.</p></div><div className="timer-picker"><label htmlFor="duration">Thời gian làm bài</label><select id="duration" value={minutes} onChange={(event) => setMinutes(Number(event.target.value))}>{[20, 30, 40, 50, 60, 70, 80].map((value) => <option key={value} value={value}>{value} phút</option>)}</select></div><div className="setup-parts">{parts.map((part, index) => <section className="part-form" key={index}><h2>Part {index + 1}</h2><label><span>Passage</span><textarea value={part.passage} onChange={(event) => updatePart(index, 'passage', event.target.value)} placeholder={`Nhập passage cho Part ${index + 1}...`} /></label><label><span>Questions</span><textarea value={part.questions} onChange={(event) => updatePart(index, 'questions', event.target.value)} placeholder={`Nhập câu hỏi cho Part ${index + 1}...`} /></label></section>)}</div><div className="setup-actions"><button className="sample-button" onClick={useSample}><RotateCcw size={16} /> Dùng nội dung mẫu</button><button className="start-button" onClick={onStart} disabled={!ready}>Bắt đầu bài đọc <ChevronRight size={18} /></button></div><p className="setup-note">Trong bài thi, bôi đen đoạn văn rồi bấm nút Highlight nhỏ xuất hiện phía trên vùng chọn.</p></div></main>
}
